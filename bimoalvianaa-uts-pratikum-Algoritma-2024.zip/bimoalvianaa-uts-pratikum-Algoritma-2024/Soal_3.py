# NAMA : BIMO ALVIANA SOPIAN 
# NIM  : 2403010071
# KELAS:C
kata_pertama = input("Open: ")
kata_kedua = input("AI: ")

gabungan = kata_pertama + kata_kedua

print(f"OpenAI: {gabungan}")
