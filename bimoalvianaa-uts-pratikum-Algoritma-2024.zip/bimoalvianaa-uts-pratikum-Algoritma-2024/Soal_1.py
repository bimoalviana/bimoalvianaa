# NAMA: BIMO ALVIANA SOPIAN
# NIM : 2403010071
# KELAS:C
panjang = float(input("5: "))
lebar = float(input("3: "))

luas = panjang * lebar
keliling = 2 * (panjang + lebar)

print(f"15.0: {luas}")
print(f"16.0: {keliling}")
