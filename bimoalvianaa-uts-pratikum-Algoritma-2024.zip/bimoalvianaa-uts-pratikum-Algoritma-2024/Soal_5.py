# NAMA : BIMO ALVIANA SOPIAN
# NIM  : 2403010071
# KELAS:C
kata = input("Algoritma: ")

indeks_awal = int(input("2: "))
indeks_akhir = int(input("6: "))

substring = kata[2:6]

print(f"Substring: {gori}")
