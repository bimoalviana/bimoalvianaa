# NAMA:BIMO ALVIANA SOPIAN
# NIM :2403010071
# KELAS:c
celcius = float(input("25: "))

fahrenheit = (celcius * (9/5)) + 32

print(f"77.0: {fahrenheit}")
